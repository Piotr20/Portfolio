const projects_scrim = document.querySelector('.projects_scrim');
projects_scrim.classList.add("active");