$('#menu-toggle').click(function () {
     $(this).toggleClass('open');
     $('#curtain').toggleClass('open');
})