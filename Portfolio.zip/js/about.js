ScrollReveal().reveal('.item', {
     delay: 500,
     duration: 500,
     reset: true,
     origin: "top",
});

ScrollReveal().reveal('.item1', {
     delay: 300,
     duration: 500,
     reset: true,
     origin: "top",
});
ScrollReveal().reveal('.item2', {
     delay: 400,
     duration: 500,
     reset: true,
     origin: "top",
});
ScrollReveal().reveal('.item3', {
     delay: 500,
     duration: 500,
     reset: true,
     origin: "top",
});
ScrollReveal().reveal('.item4', {
     delay: 600,
     duration: 500,
     reset: true,
     origin: "top",
});
ScrollReveal().reveal('.item5', {
     delay: 700,
     duration: 500,
     reset: true,
     origin: "top",
});
ScrollReveal().reveal('.item6', {
     delay: 800,
     duration: 500,
     reset: true,
     origin: "top",
});
ScrollReveal().reveal('.item7', {
     delay: 900,
     duration: 500,
     reset: true,
     origin: "top",
});
ScrollReveal().reveal('.item8', {
     delay: 1000,
     duration: 500,
     reset: true,
     origin: "top",
});
ScrollReveal({
     reset: true,
     duration: 1000,
});
const projects_scrim = document.querySelector('.projects_scrim');
projects_scrim.classList.add("active");